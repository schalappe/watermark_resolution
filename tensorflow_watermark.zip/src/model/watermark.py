# -*- coding: utf-8
"""

"""
import tensorflow as tf


def block_pre_processing(x, filters: int, kernel: int, strides: int, last: bool = False):
    """
    Sub-neural: Conv2DTranspose => BN => RELU => Pool[Average]
    if last: Conv2DTranspose => Pool[Average]

    Parameters
    ----------
    x: input tensor

    filters: int
        filters of the conv layer

    kernel: int
        kernel size of the bottleneck layer

    strides: int
        stride for conv layer

    last: bool
        if true, not normalize layer and activation

    Returns
    -------
        Output tensor for the block.
    """
    x = tf.keras.layers.Conv2DTranspose(filters=filters, kernel_size=kernel, strides=strides)(x)
    if not last:
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
    x = tf.keras.layers.AveragePooling2D(pool_size=2, strides=1)(x)

    return x


def block_extract(x, filters: int, kernel: int, strides: int):
    """
    Sub-neural: Conv2D => BN => RELU

    Parameters
    ----------
    x: input tensor

    filters: int
        filters of the conv layer

    kernel: int
        kernel size of the bottleneck layer

    strides: int
        stride for conv layer

    Returns
    -------
        Output tensor for the block.
    """
    x = tf.keras.layers.Conv2D(filters=filters, kernel_size=kernel, strides=strides, padding="same")(x)
    x = tf.keras.layers.BatchNormalization()(x)
    x = tf.keras.layers.ReLU()(x)

    return x


def stack_pre_processing(x, blocks: list, kernel: int, strides: int):
    """

    Parameters
    ----------
    x: input tensor

    blocks: list
        list of filters for conv layers

    kernel: int
        kernel size of the bottleneck layer

    strides: int
        stride for conv layer

    last: bool
        if true, not normalize layer and activation

    Returns
    -------
        Output tensor for the block.
    """
    for filters in blocks:
        x = block_pre_processing(x, filters=filters, kernel=kernel, strides=strides)
    return x


def stack_extract(x, blocks: list, kernel: int, strides: int):
    """

    Parameters
    ----------
    x: input tensor

    blocks: list
        list of filters for conv layers

    kernel: int
        kernel size of the bottleneck layer

    strides: int
        stride for conv layer

    last: bool
        if true, not normalize layer and activation

    Returns
    -------
        Output tensor for the block.
    """
    for filters in blocks:
        x = block_extract(x, filters=filters, kernel=kernel, strides=strides)
    return x


def block_embedding(x, filters: int, kernel: int, strides: int, last: bool = False):
    """
    Sub-neural: Conv2D => BN => RELU
    if last: Conv2D => TANH

    Parameters
    ----------
    x: input tensor

    filters: int
        filters of the conv layer

    kernel: int
        kernel size of the bottleneck layer

    strides: int
        stride for conv layer

    last: bool
        if true, not normalize layer and activation

    Returns
    -------
        Output tensor for the block.
    """
    x = tf.keras.layers.Conv2D(filters=filters, kernel_size=kernel, strides=strides, padding="same")(x)
    if not last:
        x = tf.keras.layers.BatchNormalization()(x)
        x = tf.keras.layers.ReLU()(x)
    else:
        x = tf.keras.activations.tanh(x)

    return x


class WaterMark:
    @staticmethod
    def build(image_dims: tuple, mark_dims: tuple, strength: float = 1):
        """
        Create a Watermark network
        Parameters
        ----------
        image_dims: tuple
            Dimension of image

        mark_dims: tuple
            Dimension of marg

        strength: float
            Strength scaling factor for controlling the watermark’s invisibility
            and the robustness against attacks

        Returns
        -------
            Model for watermarking an image
        """
        # mark pre-processing network
        input_mark = tf.keras.Input(shape=mark_dims)
        output_mark = stack_pre_processing(input_mark, blocks=[512, 256, 128], kernel=3, strides=2)
        output_mark = block_pre_processing(output_mark, filters=1, kernel=3, strides=2, last=True)
        # TODO: strength factor as hyperparameters
        # output_imge = tf.math.scalar_mul(strength, output_mark)

        # image pre-processing network
        input_image = tf.keras.Input(shape=image_dims)
        output_imge = tf.keras.layers.Conv2D(filters=64, kernel_size=3, strides=1, padding="same")(input_image)

        # concatenate
        embedding = tf.keras.layers.concatenate(
            [output_imge, output_mark], axis=-1
        )

        # embedding network
        x = block_embedding(embedding, filters=64, kernel=3, strides=1)
        for _ in range(3):
            x = block_embedding(x, filters=64, kernel=3, strides=1)
        outputs = block_embedding(x, filters=image_dims[-1], kernel=3, strides=1, last=True)

        # return model
        return tf.keras.Model(inputs=[input_image, input_mark], outputs=outputs)


class ExtractWaterMark:
    @staticmethod
    def build(mark_dims: tuple):
        """
        Create an ExtractWatermark network
        Parameters
        ----------

        mark_dims: tuple
            Dimension of marg

        Returns
        -------
            Model for extracting watermark
        """
        # mark pre-processing network
        input_dims = (mark_dims[0] * 16, mark_dims[1] * 16, mark_dims[2])
        input_mark = tf.keras.Input(shape=input_dims)

        # extraction network
        x = stack_extract(input_mark, blocks=[128, 256, 512], kernel=3, strides=2)
        outputs = tf.keras.layers.Conv2D(filters=1, kernel_size=3, strides=2, activation="tanh", padding="same")(x)

        # return model
        return tf.keras.Model(inputs=input_mark, outputs=outputs)

